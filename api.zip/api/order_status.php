<?php
//this is an api to update order status users
// +-----------------------------------+
// + STEP 1: include required files    +
// +-----------------------------------+
require_once("../php_include/db_connection.php");
require_once('OrderClass.php');
require_once('../GCM.php');
//require_once ('../easyapns/apns.php');
$success=$msg="0";$data=array();

// +-----------------------------------+
// + STEP 2: get data				   +
// +-----------------------------------+
$status=$_REQUEST['status'];
$order_id=$_REQUEST['order_id'];
$vid=$_REQUEST['venue_id'];
$staff_id=$_REQUEST['staff_id'];

if(!($status && $order_id && $vid && $staff_id)){
	$success="0";
	$msg="Incomplete Parameters";
}
else{
	$sql="select * from staff_order where order_id=:order_id and venue_id=:venue_id and staff_id=:staff_id";
	$sth=$conn->prepare($sql);
	$sth->bindValue("order_id",$order_id);
	$sth->bindValue("venue_id",$vid);
	$sth->bindValue("staff_id",$staff_id);
	try{$sth->execute();}catch(Exception $e){}
	$result=$sth->fetchAll();


if(count($result)){
	$sql="update staff_order set status=:status where order_id=:order_id and venue_id=:venue_id and staff_id=:staff_id";
	$sth=$conn->prepare($sql);
	$sth->bindValue("status",$status);
	$sth->bindValue("order_id",$order_id);
	$sth->bindValue("venue_id",$vid);
	$sth->bindValue("staff_id",$staff_id);
	$count=0;
	try{$count=$sth->execute();}catch(Exception $e){}
	if($count){
	$success="1";
	$msg="order status updated successfully";

	
$data['open'] = OrderClass::get_orders($staff_id,$vid,1)? OrderClass::get_orders($staff_id,$vid,1):[];
$data['ready'] = OrderClass::get_orders($staff_id,$vid,2)? OrderClass::get_orders($staff_id,$vid,2):[];
$data['closed'] = OrderClass::get_orders($staff_id,$vid,3)? OrderClass::get_orders($staff_id,$vid,3):[];
$data['_void'] = OrderClass::get_orders($staff_id,$vid,4)? OrderClass::get_orders($staff_id,$vid,4):[];


	//For GCM..................
		$message=array();
    		$reg_ids=array();
    		$message['order_id']=$order_id;
    		if($status==1){
    		$message['msg']="Your order with id=".$order_id." is currently in progress.";
    		}
    		elseif($status==2){
    		$message['msg']="Your order with id=".$order_id." is ready.";
    		}
    		elseif($status==3){
    		$message['msg']="Your order with id=".$order_id." is delivered successfully.";
    		}
    		elseif($status==4){
    		$message['msg']="Your order with id=".$order_id." is cancelled.";
    		}
    		$sql_qry="select `order`.user_id,users.apn_id,users.reg_id from `order` left join users on users.id=`order`.user_id where `order`.id=:order_id";
    		$sth=$conn->prepare($sql_qry);
    		$sth->bindValue("order_id",$order_id);
    		$sth->execute();
    		$rst2=$sth->fetchAll(PDO::FETCH_ASSOC);
    		foreach($rst2 as $key=>$value){
    			if(!empty($value['reg_id'])){
    				$reg_ids[]=$value['reg_id'];
    			}
    			/*elseif(!empty($value['apn_id'])){
    				$apns->newMessage($value['apn_id']);
				$apns->addMessageAlert($message['msg']);
				$apns->addMessageSound('x.wav');
				$apns->addMessageCustom('order_id', $order_id);
				$apns->queueMessage();
				$apns->processQueue();
    			}*/
    			else{}
    			}
    		}
    		if(!empty($reg_ids))
    		{	
    			
    			//print_r($reg_ids);
    			//print_r($message);
    			GCM::send_notification($reg_ids, $message);
    		}
    		

}
else{
	$success="0";
	$msg="Invalid data";
}
}

// +-----------------------------------+
// + STEP 4: send json data			   +
// +-----------------------------------+
if($success==1){
echo json_encode(array("success"=>$success,"msg"=>$msg,"data"=>$data));
}
else
echo json_encode(array("success"=>$success,"msg"=>$msg));
?>