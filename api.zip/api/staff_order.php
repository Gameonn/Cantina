<?php
//this is an api staff_order 

// +-----------------------------------+
// + STEP 1: include required files    +
// +-----------------------------------+
require_once("../php_include/db_connection.php");
require_once('OrderClass.php');
$success=$msg="0";$data=array();
// +-----------------------------------+
// + STEP 2: get data				   +
// +-----------------------------------+

$sid=$_REQUEST['staff_id'];
$vid=$_REQUEST['venue_id'];


// +-----------------------------------+
// + STEP 3: perform operations		   +
// +-----------------------------------+


$data['open'] = OrderClass::get_orders($sid,$vid,1)? OrderClass::get_orders($sid,$vid,1):[];
$data['ready'] = OrderClass::get_orders($sid,$vid,2)? OrderClass::get_orders($sid,$vid,2):[];
$data['closed'] = OrderClass::get_orders($sid,$vid,3)? OrderClass::get_orders($sid,$vid,3):[];
$data['_void'] = OrderClass::get_orders($sid,$vid,4)? OrderClass::get_orders($sid,$vid,4):[];
// +-----------------------------------+
// + STEP 4: send json data			   +
// +-----------------------------------+
if($data['void']||$data['open']||$data['ready']||$data['closed']){
$success='1';
$msg='Records Found';
}
else{
$success=0;
$msg='No Records Found';
}

if($success==1){
echo json_encode(array("success"=>$success,"msg"=>$msg,"data"=>$data));
}
else
echo json_encode(array("success"=>$success,"msg"=>$msg));


?>