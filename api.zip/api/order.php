<?php
//this is an api to for order placing by users

// +-----------------------------------+
// + STEP 1: include required files    +
// +-----------------------------------+
require_once("../php_include/db_connection.php");
//error_reporting(E_ALL);
$success=$msg="0";$data=array();
// +-----------------------------------+
// + STEP 2: get data				   +
// +-----------------------------------+

$uid=$_REQUEST['user_id'];
$vid=$_REQUEST['venue_id'];
$coupon=$_REQUEST['coupon_code']?$_REQUEST['coupon_code']:'';
$delivery_type=$_REQUEST['delivery_type'];
$bill=$_REQUEST['bill_file'];
$payment_status=$_REQUEST['payment_status']?$_REQUEST['payment_status']:0;
$tip=$_REQUEST['tip']?$_REQUEST['tip']:'';
$order_amount=$_REQUEST['order_amount'];
$value=($tip*$order_amount)/100;
if(!($uid && $vid && $delivery_type && $bill && $order_amount)){
	$success="0";
	$msg="Incomplete Parameters";
	$data=array();
}
else{

// +-----------------------------------+
// + STEP 3: perform operations		   +
// +-----------------------------------+

	/*$sql="select * from staff where username=:username";
	$sth=$conn->prepare($sql);
	$sth->bindValue('username',$staff);
	try{$sth->execute();}
	catch(Exception $e){}
	$res=$sth->fetchAll(PDO::FETCH_ASSOC);	
	$sid=$res[0]['id'];*/
	
	$sql="select * from manager_venue where venue_id=:venue_id and is_deleted=0";
	$sth=$conn->prepare($sql);
	$sth->bindValue('venue_id',$vid);
	try{$sth->execute();}
	catch(Exception $e){}
	$res2=$sth->fetchAll(PDO::FETCH_ASSOC);
	$mid=$res2[0]['manager_id'];
	
	$sql="select temp.* from (select staff.*, (select count(staff_order.staff_id) from staff_order where staff_order.venue_id=staff.venue_id and staff_order.staff_id=staff.id and staff_order.status=1 and DATE(`staff_order`.created_on)=CURDATE()) as count from staff where staff.venue_id=:venue_id and staff.online=1 and is_live=1 and is_deleted=0) as temp order by count";
	$sth=$conn->prepare($sql);
	$sth->bindValue('venue_id',$vid);
	try{$sth->execute();}
	catch(Exception $e){echo $e->getMessage();}
	$staff=$sth->fetchAll(PDO::FETCH_ASSOC);
	$stid=$staff[0]['id'];
	
	$sql="select * from staff where venue_id=:venue_id and id=:id and is_live=1 and is_deleted=0";
	$sth=$conn->prepare($sql);
	$sth->bindValue('venue_id',$vid);
	$sth->bindValue("id",$stid);
	try{$sth->execute();}
	catch(Exception $e){}
	$staff_detail=$sth->fetchAll(PDO::FETCH_ASSOC);
	
	
	if($coupon){
	$sql="select * from coupons where coupon_code=:code and is_live=1 and is_deleted=0";
	$sth=$conn->prepare($sql);
	$sth->bindValue('code',$coupon);
	try{$sth->execute();}
	catch(Exception $e){}
	$res1=$sth->fetchAll(PDO::FETCH_ASSOC);
	$cid=$res1[0]['id'];
	if(!$cid)
	$cid=0;
	}
	else
	$cid=0;
	
	$code=rand(10000,999999);
	$t=date('m-d-Y H:i:s');
	$sql="insert into `order` values(DEFAULT,:user_id,:venue_id,:coupon_id,:delivery_type,:order_amount,:bill_file,:payment_status,:confirmation_code,NOW())";

		$sth=$conn->prepare($sql);
		$sth->bindValue("user_id",$uid);
		$sth->bindValue("venue_id",$vid);
		$sth->bindValue("coupon_id",$cid);
		$sth->bindValue("delivery_type",$delivery_type);
		$sth->bindValue("order_amount",$order_amount);
		$sth->bindValue("bill_file",$bill);
		$sth->bindValue("payment_status",$payment_status);
		$sth->bindValue("confirmation_code",$code);
		
		$count=0;
		try{$count=$sth->execute();
		$oid=$conn->lastInsertId();
		}
		catch(Exception $e){
		echo $e->getMessage();
		}
		
		$sql="insert into `user_coupons` values(DEFAULT,:user_id,:coupon_id,:order_id,NOW())";

		$sth=$conn->prepare($sql);
		$sth->bindValue("user_id",$uid);
		$sth->bindValue("coupon_id",$cid);
		$sth->bindValue("order_id",$oid);	
		$count2=0;
		try{$count2=$sth->execute();
		}
		catch(Exception $e){
		echo $e->getMessage();
		}
		
		$sql="insert into `staff_order` values(DEFAULT,:order_id,:venue_id,:staff_id,:status,NOW())";

		$sth=$conn->prepare($sql);
		$sth->bindValue("staff_id",$stid);
		$sth->bindValue("status",1);
		$sth->bindValue("order_id",$oid);
		$sth->bindValue("venue_id",$vid);	
		$count2=0;
		try{$count2=$sth->execute();
		}
		catch(Exception $e){
		echo $e->getMessage();
		}
		
		$sql="insert into `tip` values(DEFAULT,:manager_id,:user_id,:value,:order_id,NOW())";

		$sth=$conn->prepare($sql);
		$sth->bindValue("user_id",$uid);
		$sth->bindValue("manager_id",$mid);
		$sth->bindValue("value",$value);
		$sth->bindValue("order_id",$oid);
			
		$count1=0;
		try{$count1=$sth->execute();}
		catch(Exception $e){
		echo $e->getMessage();
		}
		
		
		
		if($count && $count1 && $count2){
		$msg="Order Placed";
		$success=1;
		
		//get order code
			$data['order']=array(
				"confirmation_code"=>$code,
				"order_id"=>$oid,
				"order_time"=>$t
				
			);
			
			
			}
			
		}
		

// +-----------------------------------+
// + STEP 4: send json data			   +
// +-----------------------------------+
if($success==1){
echo json_encode(array("success"=>$success,"msg"=>$msg,"data"=>$data,"staff"=>$staff_detail));
}
else
echo json_encode(array("success"=>$success,"msg"=>$msg));
?>