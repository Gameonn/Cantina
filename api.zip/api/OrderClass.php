<?php

class OrderClass{
	
public static function get_orders($sid,$vid,$status){
	
global $conn;
	
	
	$sql="SELECT `order`.*,TRUNCATE((`order`.order_amount),2) as order_amount,`order`.id as oid,order.created_on as order_time, staff_order.*,users.*,
	CASE 
                  WHEN HOUR(TIMEDIFF(NOW(),`order`.created_on)) != 0 THEN CONCAT(HOUR(TIMEDIFF(NOW(),`order`.created_on)) ,'h ago')
                  WHEN MINUTE(TIMEDIFF(NOW(),`order`.created_on)) != 0 THEN CONCAT(MINUTE(TIMEDIFF(NOW(),`order`.created_on)) ,'m ago')
                  ELSE
                     CONCAT(SECOND(TIMEDIFF(NOW(),`order`.created_on)) ,' s ago')
                END as time_elapsed
 FROM `order` join staff_order on staff_order.order_id=`order`.id and staff_order.venue_id=`order`.venue_id and staff_order.status=:status and staff_order.staff_id=:staff_id join users on users.id=`order`.user_id where `order`.venue_id=:venue_id and DATE(`order`.created_on)=CURDATE() or DATE(`order`.created_on)=CURDATE()-1 ";
	$sth=$conn->prepare($sql);
	$sth->bindValue('staff_id',$sid);
	$sth->bindValue('venue_id',$vid);
	$sth->bindValue('status',$status);
	try{$sth->execute();}
	catch(Exception $e){}
	$result=$sth->fetchAll(PDO::FETCH_ASSOC);
	
	if(count($result) ){

		$success="1";	
			foreach($result as $key=>$value){
			$obj= json_decode($value['bill_file'],true);
			
		if(!isset($final[$value['oid']])){
		
					$final[$value['oid']]=array(
					"order_id"=>$value['oid'],
		 			'time_elapsed'=>$value['time_elapsed'], 
		 			'order_time'=>$value['order_time'],
		 			'order_amount'=>$value['order_amount'],
		 			'delivery_type'=>$value['delivery_type'],
		 			'name'=>$value['username'],
		 			'email'=>$value['email'], 	
		 			 'zipcode'=>$value['zipcode'],
		 			 'mobile'=>$value['mobile'],
		 			 'user_image'=>$value['image']?BASE_PATH."timthumb.php?src=uploads/".$value['image']:BASE_PATH."timthumb.php?src=uploads/default-profilepic.jpg",
		 			  'tip'=>$obj['tip']?$obj['tip']:0,
		 			 'item'=>array()
				);
				}
			if(is_array($obj)){	
			foreach($obj as $k=>$v){
			
			
			if(is_array($v)){
			foreach($v as $key1=>$val){
			
				if(!ISSET($final[$value['oid']]['item'][$val['item_id']])){			
				$final[$value['oid']]['item'][$val['item_id']]=array('item_id'=>$val['item_id'],
				'item_name'=>$val['item_name'],
				"serving_id"=>$val['serving_id'],
			        "serving_name"=>$val['serving_name'],
				"quantity"=>$val['quantity'],
				"special_instructions"=>$val['instructions']?$val['instructions']:""
				);
					}		
				}}	
			}}
		}	
		
	$data=array();
	$data2=array();
		foreach($final as $key=>$value){
		
		foreach($value['item'] as $value2){
			$data2[]=$value2;
		}
		$final[$key]['item']=$data2;
		$data2=array();
	}
	
	foreach($final as $key=>$value){
		$data[]=$value;
	}
	return $data;
		
		
		}
	
	
	}
	
public static function get_users_orders($uid){
	
global $conn;
	
	
	$sql="SELECT `order`.*,TRUNCATE((`order`.order_amount),2) as order_amount,staff_order.status,`order`.id as oid,order.created_on as order_time,venue.id as vid,venue.*,(select pictures.url from pictures where pictures.venue_id=venue.id) as url, users.*,
	CASE 
                  WHEN DATEDIFF(NOW(),`order`.created_on) != 0 THEN CONCAT(DATEDIFF(NOW(),`order`.created_on) ,'d ago')
                  WHEN HOUR(TIMEDIFF(NOW(),`order`.created_on)) != 0 THEN CONCAT(HOUR(TIMEDIFF(NOW(),`order`.created_on)) ,'h ago')
                  WHEN MINUTE(TIMEDIFF(NOW(),`order`.created_on)) != 0 THEN CONCAT(MINUTE(TIMEDIFF(NOW(),`order`.created_on)) ,'m ago')
                  ELSE
                     CONCAT(SECOND(TIMEDIFF(NOW(),`order`.created_on)) ,' s ago')
                END as time_elapsed
 FROM `order` join venue on venue.id=order.venue_id join users on users.id=`order`.user_id left join staff_order on staff_order.order_id=`order`.id where `order`.user_id=:user_id ";
	$sth=$conn->prepare($sql);
	$sth->bindValue('user_id',$uid);
	try{$sth->execute();}
	catch(Exception $e){}
	$result=$sth->fetchAll(PDO::FETCH_ASSOC);
	
	if(count($result) ){

		$success="1";	
			foreach($result as $key=>$value){
			$obj= json_decode($value['bill_file'],true);
			
		if(!isset($final[$value['oid']])){
		
					$final[$value['oid']]=array(
					"order_id"=>$value['oid'],
		 			'time_elapsed'=>$value['time_elapsed'], 
		 			'order_status'=>$value['status'],
		 			'order_time'=>$value['order_time'],
		 			'order_amount'=>$value['order_amount'],
		 			'delivery_type'=>$value['delivery_type'],
		 			'name'=>$value['username'],
		 			'email'=>$value['email'], 	
		 			 'zipcode'=>$value['zipcode'],
		 			 'mobile'=>$value['mobile'],
		 			 'user_image'=>$value['image']?BASE_PATH."timthumb.php?src=uploads/".$value['image']:BASE_PATH."timthumb.php?src=uploads/default-profilepic.jpg",
		 			 "venue_id"=>$value['vid'],
		 			'venue_name'=>$value['venue_name'], 
		 			'venue_address'=>$value['address'],
		 			'city'=>$value['city'],
		 			'venue_contact'=>$value['mobile'],	
		 			 'venue_image'=>$value['url']?BASE_PATH."timthumb.php?src=uploads/".$value['url']:BASE_PATH."timthumb.php?src=uploads/abt-us-sdimg.jpg",
		 			 'coupon_code'=>$obj['coupon_code']?$obj['coupon_code']:0,
		 			 'tip'=>$obj['tip']?$obj['tip']:0,
		 			 'item'=>array()
				);
				}
			if(is_array($obj)){	
			foreach($obj as $k=>$v){
			
			
			if(is_array($v)){
			foreach($v as $key1=>$val){
			
				if(!ISSET($final[$value['oid']]['item'][$val['item_id']])){			
				$final[$value['oid']]['item'][$val['item_id']]=array('item_id'=>$val['item_id'],
				'item_name'=>$val['item_name'],
				"serving_id"=>$val['serving_id'],
			        "serving_name"=>$val['serving_name'],
				"quantity"=>$val['quantity'],
				"aggregate_price"=>$val['aggregate_price'],
				"item_price"=>$val['item_price'],
				"special_instructions"=>$val['instructions']?$val['instructions']:""
				);
					}		
				}}	
			}}
		}	
		
	$data=array();
	$data2=array();
		foreach($final as $key=>$value){
		
		foreach($value['item'] as $value2){
			$data2[]=$value2;
		}
		$final[$key]['item']=$data2;
		$data2=array();
	}
	
	foreach($final as $key=>$value){
		$data[]=$value;
	}
	return $data;
		
		
		}
	
	
	}
	
public static function get_order_by_id($uid,$oid){
	
global $conn;
	
	
	$sql="SELECT `order`.*,TRUNCATE((`order`.order_amount),2) as order_amount,staff_order.status,`order`.id as oid,order.created_on as order_time,venue.id as vid,venue.*,(select pictures.url from pictures where pictures.venue_id=venue.id) as url, users.*,
	CASE 
                  WHEN DATEDIFF(NOW(),`order`.created_on) != 0 THEN CONCAT(DATEDIFF(NOW(),`order`.created_on) ,'d ago')
                  WHEN HOUR(TIMEDIFF(NOW(),`order`.created_on)) != 0 THEN CONCAT(HOUR(TIMEDIFF(NOW(),`order`.created_on)) ,'h ago')
                  WHEN MINUTE(TIMEDIFF(NOW(),`order`.created_on)) != 0 THEN CONCAT(MINUTE(TIMEDIFF(NOW(),`order`.created_on)) ,'m ago')
                  ELSE
                     CONCAT(SECOND(TIMEDIFF(NOW(),`order`.created_on)) ,' s ago')
                END as time_elapsed
 FROM `order` join venue on venue.id=order.venue_id join users on users.id=`order`.user_id left join staff_order on staff_order.order_id=`order`.id where `order`.user_id=:user_id and `order`.id=:order_id ";
	$sth=$conn->prepare($sql);
	$sth->bindValue('user_id',$uid);
	$sth->bindValue('order_id',$oid);
	try{$sth->execute();}
	catch(Exception $e){}
	$result=$sth->fetchAll(PDO::FETCH_ASSOC);
	
	if(count($result) ){

		$success="1";	
			foreach($result as $key=>$value){
			$obj= json_decode($value['bill_file'],true);
			
		if(!isset($final[$value['oid']])){
		
					$final[$value['oid']]=array(
					"order_id"=>$value['oid'],
		 			'time_elapsed'=>$value['time_elapsed'], 
		 			'order_time'=>$value['order_time'],
		 			'order_status'=>$value['status'],
		 			'order_amount'=>$value['order_amount'],
		 			'delivery_type'=>$value['delivery_type'],
		 			'name'=>$value['username'],
		 			'email'=>$value['email'], 	
		 			 'zipcode'=>$value['zipcode'],
		 			 'mobile'=>$value['mobile'],
		 			 'user_image'=>$value['image']?BASE_PATH."timthumb.php?src=uploads/".$value['image']:BASE_PATH."timthumb.php?src=uploads/default-profilepic.jpg",
		 			 "venue_id"=>$value['vid'],
		 			'venue_name'=>$value['venue_name'], 
		 			'venue_address'=>$value['address'],
		 			'city'=>$value['city'],
		 			'venue_contact'=>$value['mobile'],	
		 			 'venue_image'=>$value['url']?BASE_PATH."timthumb.php?src=uploads/".$value['url']:BASE_PATH."timthumb.php?src=uploads/abt-us-sdimg.jpg",
		 			 'coupon_code'=>$obj['coupon_code']?$obj['coupon_code']:0,
		 			 'tip'=>$obj['tip']?$obj['tip']:0,
		 			 'item'=>array()
				);
				}
			if(is_array($obj)){	
			foreach($obj as $k=>$v){
			
			
			if(is_array($v)){
			foreach($v as $key1=>$val){
			
				if(!ISSET($final[$value['oid']]['item'][$val['item_id']])){			
				$final[$value['oid']]['item'][$val['item_id']]=array('item_id'=>$val['item_id'],
				'item_name'=>$val['item_name'],
				"serving_id"=>$val['serving_id'],
			        "serving_name"=>$val['serving_name'],
				"quantity"=>$val['quantity'],
				"aggregate_price"=>$val['aggregate_price'],
				"item_price"=>$val['item_price'],
				"special_instructions"=>$val['instructions']?$val['instructions']:""
				);
					}		
				}}	
			}}
		}	
		
	$data=array();
	$data2=array();
		foreach($final as $key=>$value){
		
		foreach($value['item'] as $value2){
			$data2[]=$value2;
		}
		$final[$key]['item']=$data2;
		$data2=array();
	}
	
	foreach($final as $key=>$value){
		$data[]=$value;
	}
	return $data;
		
		
		}
	
	
	}
}
	
	
	
?>	