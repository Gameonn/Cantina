<?php 
$tmp=$_FILES['pic'];

print_r($_FILES);


?>