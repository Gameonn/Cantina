<?php session_start();?>
<?php require_once "../php_include/db_connection.php"; ?>
<?php require_once "../php_include/manager_header.php"; ?>
<?php require_once "../GeneralFunctions.php"; ?>
	
<?php
   $menuid=$_REQUEST['menu_id'];
   $pid=$_REQUEST['pid'];
	
  $obj = new GeneralFunctions; 
  $sql="SELECT id from manager where token=:token and is_deleted=0";
  $sth=$conn->prepare($sql);
  $sth->bindValue("token",$key);
  try{$sth->execute();}catch(Exception $e){}
  $mgid=$sth->fetchAll();
  $mid=$mgid[0]['id'];

  $sql="SELECT id from manager_venue where manager_id=:manager_id and is_live=1 and is_deleted=0";
  $sth=$conn->prepare($sql);
  $sth->bindValue("manager_id",$mid);
  try{$sth->execute();}catch(Exception $e){}
  $r=$sth->fetchAll();
  $vid=$r[0]['id'];

 	
  $sql="SELECT id,type from servings where menucategory_id=:menucategory_id";
  $sth=$conn->prepare($sql);
  $sth->bindValue("menucategory_id",$menuid);
  try{$sth->execute();}catch(Exception $e){ }
  $servings=$sth->fetchAll();
  
 $sql="SELECT * FROM `tax` where id IN (select tax_id from category_tax where menucategory_id=:menucategory_id and is_deleted=0)";
    $sth=$conn->prepare($sql);
    $sth->bindValue("menucategory_id",$menuid);
    try{$sth->execute();}catch(Exception $e){ }
    $taxes=$sth->fetchAll();
    
     $sql="SELECT * FROM  `pricing_names` ";
    $sth=$conn->prepare($sql);
    try{$sth->execute();}catch(Exception $e){ }
    $names=$sth->fetchAll();

  ?>
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8">
    <title>Gambay| Dashboard</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- bootstrap 3.0.2 -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- font Awesome -->
    <link href="../assets/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="../assets/css/AdminLTE.css" rel="stylesheet" type="text/css" />
    
  </head>
  <!--CSS DATA TABLES -->
  <link href="../assets/css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
  <style>
  .modal-title {text-align: center!important;}
    .table-bordered>thead>tr>th, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>tbody>tr>td, .table-bordered>tfoot>tr>td {
  text-align: center; vertical-align: middle; }
  </style>
  <body>
    <div class="wrapper row-offcanvas row-offcanvas-left">
      <!-- Left side column. contains the logo and sidebar -->
      <?php require_once "../php_include/manager_leftmenu.php"; ?>
      <!-- right-side -->
      <aside class="right-side">                
        <!-- Content Header (Page header) -->
        <section class="content-header">
                    <h1>
                       Add Item
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i>Home</a></li>
                         <li><a href="menu_items.php"><i class="fa fa-suitcase"></i>Menu Items</a></li>
                          <li><a href="#"><i class="fa fa-tags"></i>Add Item</a></li>
                    </ol>
                </section>

       <section class="content" style="text-align:center;">
            <?php //error div
            if(isset($_REQUEST['success']) && isset($_REQUEST['msg']) && $_REQUEST['msg']){ ?>
            <div style="margin:0px 0px 10px 0px;" class="alert alert-<?php if($_REQUEST['success']) echo "success"; else echo "danger"; ?> alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?php echo $_REQUEST['msg']; ?>
            </div>
            <?php } // --./ error -- ?>
            
            
            <form action="functions.php" method="post" enctype="multipart/form-data">
              <div class="body bg-gray">
                    <?php //error div
                    if(isset($_REQUEST['success']) && isset($_REQUEST['msg']) && $_REQUEST['msg']){ ?>
                    <div style="margin:0px 0px 10px 0px;" class="alert alert-<?php if($_REQUEST['success']) echo "success"; else echo "danger"; ?> alert-dismissable">
                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                      <?php echo $_REQUEST['msg']; ?>
                    </div>
                    <?php } // --./ error -- ?>
                    

                    <div class="col-md-8">
                      <div class="form-group">
                           <input type="text" name="itemname" class="form-control" placeholder="Item Name" required/>

                      </div>               
                      <div class="row form-group">
                        <div class="col-md-6">
                      <label> Servings</label><br>
                        <select id="serving" name="serving_id">
                        <?php foreach($servings as $serving) {?>
                         <option value="<?php echo $serving['id']; ?>"><?php echo $serving['type']; ?></option>
			<?php } ?>	
                       </select>
                       </div> 
                        
                       <div class="col-md-6">
                      <label> Choose Tax</label><br>
                        <select id="tax" multiple="multiple" name="taxes[]">
                        <?php foreach($taxes as $tax) {?>
                         <option value="<?php echo $tax['id']; ?>"><?php echo $tax['tax_name']; ?></option>
			<?php } ?>
                      
                       </select>
                      </div>
                    </div> 
                    <div class="row form-group">
                       <label> Select Prices</label><br>
                       
                         <?php foreach($names as $name){ ?>
              
              <div class="col-md-1" style="margin-top: 8px;">
                <input type="radio" name="pricing_name_id" value="<?php echo $name['id']; ?>" class="flat-red" />
              </div>
              <div class="col-md-6">
                <input  name="p_name[]" class="form-control" value="<?php echo $name['name']; ?>" readonly/>
              </div>
              
              <div class="col-md-2">
                <input type="text" name="qty[]" class="form-control" placeholder="Unlimited" />
              </div>
               <div class="col-md-3">
                <input type="text" name="item_price[]" class="form-control" placeholder="Item Price" />
              </div>
              <?php } ?>
                    </div> 
                    <div class="row form-group">
                      
                      <label> Mark Item as Special </label>
                      
                        <select id="item_pricing" name="special_flag">
                        <option value="1" >Yes</option>
                        <option value="0">No</option>
	          </select>
                      </div>  
                    
                </div>
                <div class="col-md-4 image-upload">
                  <img src="../uploads/steam_workshop_default_image.png" class="def-image" style="width: 250px;height: 200px; padding: 3px;border: 1px solid rgb(213, 206, 206);
                  border-radius: 4px;">
                  <input type="file" name="image" style="display: inline; padding-top:15px;">
                </div>
              </div>
              <div class="footer" style="width: 50%;margin-left: auto;margin-right: auto;">                                                               
                <button type="submit" class="btn bg-olive btn-block" onclick="return 0;">Submit</button>
                <input type="button" class="btn bg-red btn-block" onclick="window.history.back()" value="Cancel">
              </div>
              <!-- hidden -->
              <input type="hidden" name="token" value="<?php echo $key; ?>">
              <input type="hidden" name="vid" value="<?php echo $vid; ?>">
              <input type="hidden" name="menucategory_id" value="<?php echo $menuid; ?>">
              <input type="hidden" name="pid" value="<?php echo $pid; ?>">
              <input type="hidden" name="event" value="add-item">
              <input type="hidden" name="redirect" value="add_item.php">

              
            </form>
      
          </section><!-- /.content -->
        </aside><!-- /.right-side -->
      </div><!-- ./wrapper -->

      <!-- add new calendar event modal -->


      <!-- jQuery 2.0.2 -->
      <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
      <!-- jQuery UI 1.10.3 -->
      <script src="../assets/js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
      <!-- Bootstrap -->
      <script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>
       <script src="../assets/js/plugins/timepicker/bootstrap-timepicker.min.js" type="text/javascript"></script>
      <!-- Morris.js charts -->
      <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
      <script src="../assets/js/plugins/morris/morris.min.js" type="text/javascript"></script>
      <!-- jvectormap -->
      <script src="../assets/js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
      <script src="../assets/js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
      <!-- Bootstrap WYSIHTML5 -->
      <script src="../assets/js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
      
      <!-- iCheck -->
      <script src="../assets/js/plugins/iCheck/icheck.min.js" type="text/javascript"></script>

      <!-- AdminLTE App -->
      <script src="../assets/js/AdminLTE/app.js" type="text/javascript"></script>
      
      <!-- DATA TABES SCRIPT -->
      <script src="../assets/js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
      <script src="../assets/js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
      <script src="../assets/js/bootstrap-multiselect.js" type="text/javascript"></script>
 
      <script type="text/javascript">
       $(document).ready(function() {
        $('#serving').multiselect({
  //includeSelectAllOption: true
	});
	$('#tax').multiselect({
  //includeSelectAllOption: true
	});
 $(".timepicker").timepicker({
           pickTime: true
                });
                
     });
     </script>
  <script>
              //Flat red color scheme for iCheck
              $(document).ready(function() {
                $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
                  checkboxClass: 'icheckbox_flat-red',
                  radioClass: 'iradio_flat-red'
                });
              });
            </script>
     <script type="text/javascript">

      $('.image-upload').on("change","input[type='file']",function () {
                // alert('hey');
                var files = this.files;
                var reader = new FileReader();
                name=this.value;
                var this_input=$(this);
                reader.onload = function (e) {

                 this_input.parent('.image-upload').find(".def-image").attr('src', e.target.result).width(250).height(200);
               }
               reader.readAsDataURL(files[0]);
             });

    </script> 
  </body>
  </html>
  