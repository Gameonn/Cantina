<?php session_start();?>
<?php require_once "../php_include/db_connection.php"; ?>
<?php require_once "../php_include/manager_header.php"; ?>
<?php require_once "../GeneralFunctions.php"; ?>

<?php
    //error_reporting(1);
  $obj = new GeneralFunctions; 
  $sql="SELECT id from manager where token=:token and is_deleted=0";
  $sth=$conn->prepare($sql);
  $sth->bindValue("token",$key);
  try{$sth->execute();}catch(Exception $e){}
  $mgid=$sth->fetchAll();
  $mid=$mgid[0]['id'];

  $sql="SELECT venue_id from manager_venue where manager_id=:manager_id and is_live=1 and is_deleted=0";
  $sth=$conn->prepare($sql);
  $sth->bindValue("manager_id",$mid);
  try{$sth->execute();}catch(Exception $e){}
  $rx=$sth->fetchAll();
  $vid=$rx[0]['venue_id'];

  //level1 main-categories
  $sql="SELECT * from menucategory where menucategory.venue_id=:vid and is_live=1 and is_deleted=0 order by id DESC";
  $sth=$conn->prepare($sql);
  $sth->bindValue("vid",$vid);
  try{$sth->execute();}catch(Exception $e){ }
  $menus=$sth->fetchAll();

  $sql="SELECT menucategory.*,(select group_concat(tax.tax_name separator '<br>') from tax left join category_tax on category_tax.tax_id=tax.id where category_tax.menucategory_id=menucategory.id and category_tax.is_deleted=0) as tax_name,(select group_concat(servings.type separator ',') from servings) as serving from menucategory where menucategory.venue_id=:venue_id and menucategory.is_live=1 and menucategory.is_deleted=0";

  $sth=$conn->prepare($sql);
  $sth->bindValue("venue_id",$vid);
  try{$sth->execute();}catch(Exception $e){echo $e->getMessage();}
  $venuecategories=$sth->fetchAll();

  $sql="select l1.id as l1_id, l1.name  as l1_name, l2.id as l2_id, l2.name as l2_name, l3.id as l3_id, l3.name as l3_name, l4.id as l4_id, l4.name as l4_name, l5.id as l5_id, l5.name as l5_name, l6.id as l6_id, l6.name as l6_name, item.id, item.name as item_name, item.pic, servings.type as serving, pricing.quantity as qty, pricing_names.name as pr_name, serving_price.serving_id as serve_id, serving_price.item_price, serving_price.agg_price 
  from menucategory as l1 left outer join subcategory as l2  on l2.menucategory_id = l1.id and l2.parent_id=0 and l2.is_live=1 and l2.is_deleted=0 left outer join subcategory as l3
    on l3.menucategory_id=l1.id and l3.parent_id = l2.id and l3.is_live=1 and l3.is_deleted=0 left outer join subcategory as l4 on l4.menucategory_id=l1.id and l4.parent_id = l3.id and l4.is_live=1 and l4.is_deleted=0 left outer join subcategory as l5 on l5.menucategory_id=l1.id and l5.parent_id = l4.id and l5.is_live=1 and l5.is_deleted=0
left outer join subcategory as l6 on l6.menucategory_id=l1.id and l6.parent_id = l5.id and l6.is_live=1 and l6.is_deleted=0 left outer join item on item.menucategory_id=l1.id and (item.parent_id=l2.id or item.parent_id=l3.id or item.parent_id=l4.id or item.parent_id=l5.id) and item.is_live=1 and item.is_deleted=0 left join pricing on pricing.item_id=item.id and pricing.status=1 left join pricing_names on pricing_names.id=pricing.pricing_name_id left join serving_price on serving_price.pricing_id=pricing.id and serving_price.is_deleted=0
left join servings on servings.id=serving_price.serving_id where l1.venue_id=1 and l1.is_live=1 and l1.is_deleted=0
order by l1_name, l2_name, l3_name, l4_name, l5_name, l6_name";
  $sth=$conn->prepare($sql);
  $sth->bindValue("venue_id",$vid);
  try{$sth->execute();}catch(Exception $e){}
  $data=$sth->fetchAll();
  ?>
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8">
    <title>Gambay| Menu Dashboard</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Category Block Design -->
    <link rel="stylesheet" href="../assets/css/my.css" type="text/css" />  
  </head>
  <style>
    .modal-title {text-align: center!important;}
    .table-bordered>thead>tr>th, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>tbody>tr>td, .table-bordered>tfoot>tr>td {
      text-align: center; vertical-align: middle; }
      .fa {
        line-height: 1.5;}
      </style>
      <body style="overflow-y: hidden;">
        <div class="wrapper row-offcanvas row-offcanvas-left">
          <!-- Left side column. contains the logo and sidebar -->
          <?php require_once "../php_include/manager_leftmenu.php"; ?>
          <!-- right-side -->
          <aside class="right-side">                
            <!-- Content Header (Page header) -->
            <section class="content-header">
              <h1>
                Menu Dashboard
              </h1>
              <ol class="breadcrumb">
                <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#"><i class="fa fa-suitcase"></i> Menu Dashboard</a></li>
              </ol>
            </section>

            <!-- Main content -->
            <section class="content">
              <?php //error div
              if(isset($_REQUEST['success']) && isset($_REQUEST['msg']) && $_REQUEST['msg']){ ?>
              <div style="margin:0px 0px 10px 0px;" class="alert alert-<?php if($_REQUEST['success']) echo "success"; else echo "danger"; ?> alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $_REQUEST['msg']; ?>
              </div>
              <?php } // --./ error -- ?>
              <div class="container">
              
              <div class="col-xs-12">
                            <div class="box">
                            <div class="box-header">
                                    <h3 class="box-title">Menu Dashboard</h3>
                                    <div class="box-tools" style="text-align: right;  padding-right: 20px;padding-bottom: 0px;padding-top: 0px;">
                                        <div class="btn-group" style="margin-top:10px;margin-left:10px;text-align: center;">
						<button class="btn btn-warning btn-sm dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bars"></i> Export Table Data</button> 
								<ul class="dropdown-menu " role="menu">
									<li><a href="#" onclick="$('#summary_table').tableExport({type:'csv',escape:'false'});">CSV</a></li>				
									<li><a href="#" onclick="$('#summary_table').tableExport({type:'excel',escape:'false'});">XLS</a></li>
							<!-- <li><a href="#" onclick="$('#summary_table').tableExport({type:'pdf',pdfFontSize:'7',escape:'false'});">PDF</a></li> -->
								</ul>
							</div>
                                    </div>
                                </div>
                                 <div class="box-body table-responsive no-padding">
                                    <table id="summary_table" class="table table-bordered table-hover">
                                   
                                        <tr>
                                            <th>ID</th>
                                            <th>Category<br>(Level 0)</th>
                                            <th>Category<br>(Level 1)</th>
                                            <th>Category<br>(Level 2)</th>
                                            <th>Category<br>(Level 3)</th>
                                            <th>Category<br>(Level 4)</th>
                                            <th>Category<br>(Level 5)</th>
                                            <th>Item Name</th>
                                            <th>Serving Size</th>
                                            <th> Pricing Category</th>
                                            <th>Item Price</th>
                                            <th>Aggregate Price</th>
                                        </tr>
                                        <?php  $r=1;
                                        foreach($data as $row){ ?> 
                                        <tr>
                                            <td><?php echo $r; ?></td>
                                            <td><?php echo $row['l1_name']; ?></td>
                                            <td><?php if($row['l2_name']) echo $row['l2_name']; else echo '-';?></td>
                                            <td><?php if($row['l3_name']) echo $row['l3_name']; else echo '-'; ?></td>
                                            <td><?php if($row['l4_name']) echo $row['l4_name']; else echo '-'; ?></td>
                                            <td><?php if($row['l5_name']) echo $row['l5_name']; else echo '-'; ?></td>
                                            <td><?php if($row['l6_name']) echo $row['l6_name']; else echo '-'; ?></td>
                                            <td><?php if($row['item_name']) echo $row['item_name']; else echo '-'; ?></td>
                                            <td><?php if($row['pr_name']) echo $row['pr_name']; else echo '-';?></td>
                                            <td><?php if($row['serving']) echo $row['serving']; else echo '-'; ?></td>
                                            <td><?php if($row['item_price']) echo $row['item_price']; else echo '-'; ?></td>
                                            <td><?php if($row['agg_price']) echo $row['agg_price']; else echo '-'; ?></td>
                                        </tr>
                                        <?php
                                        $r++;
                                         } ?>
                                     </table>
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                </div>

   </section><!-- /.content -->
 </aside><!-- /.right-side -->
</div><!-- ./wrapper -->




<!-- jQuery 2.0.2 -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
<!-- jQuery UI 1.10.3 -->
<script src="../assets/js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
<!-- Bootstrap -->
<script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>
<!-- Morris.js charts -->
<script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="../assets/js/plugins/morris/morris.min.js" type="text/javascript"></script>
<!-- jvectormap -->
<script src="../assets/js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
<script src="../assets/js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="../assets/js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
<!-- iCheck -->
<script src="../assets/js/plugins/iCheck/icheck.min.js" type="text/javascript"></script>
<script type="text/javascript" src="../assets/js/tableExport.js"></script>
<script type="text/javascript" src="../assets/js/jquery.base64.js"></script>
<!-- AdminLTE App -->
<script src="../assets/js/AdminLTE/app.js" type="text/javascript"></script>
<!-- Category Block effect -->
<script src="../assets/js/my.js" type="text/javascript"></script>
<!-- DATA TABES SCRIPT -->
<script src="../assets/js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
<script src="../assets/js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
   <script src="../assets/js/jquery.custom-scrollbar.js" type="text/javascript"></script>
<script>

              //Flat red color scheme for iCheck
              $(document).ready(function() {
                $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
                  checkboxClass: 'icheckbox_flat-red',
                  radioClass: 'iradio_flat-red'
                });

              });
            </script>
          </body>
          </html>