<?php 
//this page is to handle all the admin events occured at client side
 require_once("../php_include/db_connection.php"); 
 error_reporting(1);
require_once('../PHPMailer_5.2.4/class.phpmailer.php');
function randomFileNameGenerator($prefix){
	$r=substr(str_replace(".","",uniqid($prefix,true)),0,20);
	if(file_exists("../uploads/$r")) randomFileNameGenerator($prefix);
	else return $r;
}
$success=0;
$msg="";

//switch case to handle different events
switch($_REQUEST['event']){
	case "signin":     
	
		$success=0;
		$user=$_REQUEST['username'];
		$password=$_REQUEST['password'];
		$redirect=$_REQUEST['redirect'];
		$sth=$conn->prepare("select * from admin where (name=:name or email=:email)");
		$sth->bindValue("name",$user);
		$sth->bindValue("email",$user);
		$count=0;
		try{$count=$sth->execute();}catch(Exception $e){
		//echo $e->getMessage();
		}
		$result=$sth->fetchAll(PDO::FETCH_ASSOC);
		
		if($count && count($result)){
			foreach($result as $row){
		
				if($row['password']==md5($password)){
					session_start();
					$success=1;
					
					$_SESSION['admin']['id']=$row['id'];
					$_SESSION['admin']['username']=$row['name'];
					$_SESSION['admin']['email']=$row['email'];
					
				}
			}
		}
		if(!$success){
			$redirect="index.php";
			$msg="Invalid Username/Password";
		}
		header("Location: $redirect?success=$success&msg=$msg");
		break;
	
		case "manager-signin":     
	
		$success=0;
		$user=$_REQUEST['username'];
		$password=$_REQUEST['password'];
		$redirect=$_REQUEST['redirect'];
		$base='http://www.code-brew.com/projects/gambay/';
		$add='venue/';
		$sth=$conn->prepare("select * from manager where (username=:username or email=:email)");
		$sth->bindValue("username",$user);
		$sth->bindValue("email",$user);
		$count=0;
		try{$count=$sth->execute();}catch(Exception $e){
		//echo $e->getMessage();
		}
		$result=$sth->fetchAll(PDO::FETCH_ASSOC);
		
		if($count && count($result)){
			foreach($result as $row){
		
				if($row['password']==md5($password)){
					session_start();
					$success=1;
					
					$_SESSION['manager']['id']=$row['id'];
					$_SESSION['manager']['username']=$row['username'];
					$_SESSION['manager']['email']=$row['email'];
					
				}
			}
		}
		if(!$success){
			$redirect="index.php";
			$msg="Invalid Username/Password";
		}
		header("Location: $base$add$redirect?success=$success&msg=$msg");
		break;
	
	case 'add-vtype':
    //print_r($_REQUEST);
    $vtype=$_REQUEST['name'];
       $vtype= strip_tags($vtype);
    $vtype= htmlspecialchars($vtype);
    if($vtype){
      $sth=$conn->prepare("insert into venuetype values(DEFAULT,:type)");
      $sth->bindValue("type",$vtype);
      try{$sth->execute();
       $vtpe_id=$conn->lastInsertId();
      }
      catch(Exception $e){
        echo $e->getMessage();
      }
      echo $vtype_id;
    }

    break;
  
    case "get-venues":
  //print_r($_REQUEST);
     $vtype_id=$_REQUEST['vtype_id'];
    $sql="SELECT * FROM `venue` where venuetype_id=:vtypeid";
    $sth=$conn->prepare($sql);
    $sth->bindValue("vtypeid",$vtype_id);
    try{$sth->execute();}
    catch(Exception $e){ echo $e->getMessage();}
    $venues=$sth->fetchAll();
    //print_r($venues);
     if(count($venues))
   echo json_encode($venues);
   else
  echo '0';
  break;
  
  case "remove-cusine":
  //print_r($_REQUEST);
     $vtype_id=$_REQUEST['vtype_id'];
    $sql="SELECT * FROM `venue` where venuetype_id=:vtypeid";
    $sth=$conn->prepare($sql);
    $sth->bindValue("vtypeid",$vtype_id);
    try{$sth->execute();}
    catch(Exception $e){ echo $e->getMessage();}
    $venues=$sth->fetchAll();
    //print_r($venues);
     if(!count($venues)){
       $sql="DELETE FROM `venuetype` where id=:vtypeid";
    $sth=$conn->prepare($sql);
    $sth->bindValue("vtypeid",$vtype_id);
    try{$sth->execute();}
    catch(Exception $e){ 
   //echo $e->getMessage();
    }
    echo '3';
     }
   else
  echo 'x';
  
  break;
	
	case "signout":
	session_start();
		unset($_SESSION);
		session_destroy();
		header("Location: index.php?success=1&msg=Signout Successful!");
		break;
		
	case "reset-password":
		$token=$_REQUEST["token"];
		$password=$_REQUEST["password"];
		$confirm=$_REQUEST["confirm"];
		if($password==$confirm){
				$sth=$conn->prepare("update users set password=:password where token=:token");
				$sth->bindValue("token",$token);
				$sth->bindValue("password",$password);
				$count=0;
				try{$count=$sth->execute();}catch(Exception $e){echo $e;}
				if($count){
					$success=1;
					$msg="Password changed successfully";
				}
			}else{
				$success=0;
				$msg="Passwords didn't match";
			}
	
	break;
	
	case "manager-signout":
	$base="http://www.code-brew.com/projects/gambay/";
	$add="venue/index.php";
	session_start();
		unset($_SESSION);
		session_destroy();
		header("Location: $base$add?success=1&msg=Signout Successful!");
		break;
		
	case "manager-signup":

		$base='http://www.code-brew.com/projects/gambay/';
		$redirect=$_REQUEST['redirect'];
		$key=$_REQUEST['key'];
		$username=$_REQUEST['username'];
		$email=$_REQUEST['email'];
		$password=$_REQUEST['password'];
		$confirm=$_REQUEST['confirm'];
		$mobile=$_REQUEST['mobile']?$_REQUEST['mobile']:'';
		$image=$_FILES['pic'];
		
		if(!($username && $email && $password )){
	$success="0";
	$msg="Incomplete Parameters";
	$redirect="venue/manager_signup.php?key=".$key;
	header("Location: $base$redirect&success=$success&msg=$msg");
}


	elseif($image["error"]>0){
		$success="0";
		$msg="Invalid image";
		if($image["error"]==4) $success="1"; //image is not mandatory
	}
	//upload image
	elseif(in_array($image['type'],array("image/gif","image/jpeg","image/jpg","image/png","image/pjpeg","image/x-png")) && in_array(end(explode(".",$image['name'])), array("gif","jpeg","jpg","png"))){
		$randomFileName=randomFileNameGenerator("Img_").".".end(explode(".",$image['name']));
		if(@move_uploaded_file($image['tmp_name'], "../uploads/$randomFileName")){
			$success="1";
			$image_path=$randomFileName;
		}
		else{
			$success="0";
			$msg="Error in uploading image";
			$redirect="venue/manager_signup.php?key=".$key;
			header("Location: $base$redirect&success=$success&msg=$msg");
		}
	}
	else{
		$success="1";
		$msg="Invalid Image";
	}
		
		
		
		
		if($success=="1"){ 
		if($confirm==$password){
		
		$code=md5($username . rand(1,9999999));
		//echo $username.$password.$mobile.$image_path;
		$sth=$conn->prepare("update manager set password=:password, mobile_number=:mobile, token=:token, pic=:pic where username=:username");
			$sth->bindValue("username",$username);
			$sth->bindValue("password",md5($password));
			$sth->bindValue("mobile",$mobile);
			$sth->bindValue("pic",$image_path);
			$sth->bindValue("token",$code);
			$count=0;
			try{$count=$sth->execute();}catch(Exception $e){
			//echo $e->getMessage();
			}
			
		
			if($count)
			$msg="Details updated";
			$add="venue/";
			header("Location: $base$add$redirect");
		
		}
		else{
		//delete image
	if($image_path){ if(@unlink("../uploads/$image_path")){}}
		$msg="Password Doesnot match";
		$redirect="venue/manager_signup.php?key=".$key;
		header("Location: $base$redirect&success=$success&msg=$msg");
		}
		}
		
		break;
		
	case "create-user":
	
		$redirect=$_REQUEST['redirect'];
		$username=$_REQUEST['username'];
		$email=$_REQUEST['email'];
			
		$sth=$conn->prepare("select * from manager where username=:username or email=:email");
	$sth->bindValue("username",$username);
	$sth->bindValue("email",$email);
	
	try{$sth->execute();}catch(Exception $e){}
	$result=$sth->fetchAll(PDO::FETCH_ASSOC);
	if(count($result)){
		$success="0";
		if($username==$result[0]['username'])
			$msg="Username is already taken";
		else
			$msg="Email is already registered";
			
			
			$redirect="create_user.php";
		
		}
		else{
		$success="0";
		$code=md5($username . rand(1,9999999));
		$sql="insert into manager values(DEFAULT,:username,:email,'','',:token,'',0,NOW())";
		$sth=$conn->prepare($sql);
		$sth->bindValue("username",$username);
		$sth->bindValue("email",$email);
		$sth->bindValue("token",$code);
		
		$count1=0;
		try{$count1=$sth->execute();}catch(Exception $e){/*echo $e->getMessage();*/}
		
		if($count1)
		$msg="Users Successfully registered";
		
		
		//mail
				$smtp_username = SMTP_USER;
			$smtp_email = SMTP_EMAIL;
			$smtp_password = SMTP_PASSWORD;
			$smtp_name = SMTP_NAME;
			$subjectMail = 'Welcome to Gambay - Verify your email';
			$mail = new PHPMailer(true); 
			$mail->IsSMTP(); // telling the class to use SMTP
			try {
			  $mail->Host       = SMTP_HOST; // SMTP server
			  $mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
			  $mail->SMTPAuth   = true;                  // enable SMTP authentication
			  $mail->Host       = SMTP_HOST; // sets the SMTP server
			  $mail->Port       = SMTP_PORT;                    // set the SMTP port for the GMAIL server
			  $mail->Username   = $smtp_username; // SMTP account username
			  $mail->Password   = $smtp_password;        // SMTP account password
			  $mail->AddAddress($email);     // SMTP account password
			  $mail->SetFrom($smtp_email, $smtp_name);
			  $mail->AddReplyTo($smtp_email, $smtp_name);
			  $mail->Subject = $subjectMail;
			  $mail->AltBody = 'To view the message, please use an HTML compatible email viewer!'; // optional - MsgHTML will create an alternate automatically
			  $mail->MsgHTML('Welcome to Gambay!  Please verify your email address<br>'.BASE_PATH.'venue/manager_signup.php?key='.$code) ;
			  if(!$mail->Send()){
				//echo json_encode(array('success'=>'0','msg'=>'Error while sending Mail'));
			  }else{
				// echo json_encode(array('success'=>'1','msg'=>'Signup Complete Verify Email'));
			  }
			} catch (phpmailerException $e) {
			  //echo $e->errorMessage(); //Pretty error messages from PHPMailer
			} catch (Exception $e) {
			 // echo $e->getMessage(); //Boring error messages from anything else!
			}
		}	
	
		header("Location: $redirect?success=$success&msg=$msg");
		break;
		
		
	case "add-staff":
	
		$redirect=$_REQUEST['redirect'];
		$base="http://www.code-brew.com/projects/gambay/";
		$add="venue/";
		$user=$_REQUEST['username'];
		$email=$_REQUEST['email'];
		$password=$_REQUEST['password'];
		$vid=$_REQUEST['venue_id'];
		$mobile=$_REQUEST['mobile'] ? $_REQUEST['mobile'] : '';
		$username='bgmb_'.$user;
			
		$sth=$conn->prepare("select * from staff where username=:username ");
	$sth->bindValue("username",$username);
	//$sth->bindValue("email",$email);
	
	try{$sth->execute();}catch(Exception $e){}
	$result=$sth->fetchAll(PDO::FETCH_ASSOC);
	if(count($result)){
		$success="0";
		if($username==$result[0]['username'])
			$msg="Username is already taken";
		}
		else{
		$success="0";
		$code=md5($username . rand(1,9999999));
		$sql="insert into staff values(DEFAULT,:venue_id,:username,'',:email,:password,0,:token,:mobile,1,0,NOW())";
		$sth=$conn->prepare($sql);
		$sth->bindValue("venue_id",$vid);
		$sth->bindValue("username",$username);
		$sth->bindValue("email",$email);
		$sth->bindValue("password",md5($password));
		$sth->bindValue("token",$code);
		$sth->bindValue("mobile",$mobile);
		
		$count1=0;
		try{$count1=$sth->execute();}catch(Exception $e){/*echo $e->getMessage();*/}
		
		if($count1)
		$msg="Staff member successfully registered. You can add more";
		
		
		//mail
			$smtp_username = SMTP_USER;
			$smtp_email = SMTP_EMAIL;
			$smtp_password = SMTP_PASSWORD;
			$smtp_name = SMTP_NAME;
			$subjectMail = 'Signin your account';
			$mail = new PHPMailer(true); 
			$mail->IsSMTP(); // telling the class to use SMTP
			try {
			  $mail->Host       = SMTP_HOST; // SMTP server
			  $mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
			  $mail->SMTPAuth   = true;                  // enable SMTP authentication
			  $mail->Host       = SMTP_HOST; // sets the SMTP server
			  $mail->Port       = SMTP_PORT;                    // set the SMTP port for the GMAIL server
			  $mail->Username   = $smtp_username; // SMTP account username
			  $mail->Password   = $smtp_password;        // SMTP account password
			  $mail->AddAddress($email);     // SMTP account password
			  $mail->SetFrom($smtp_email, $smtp_name);
			  $mail->AddReplyTo($smtp_email, $smtp_name);
			  $mail->Subject = $subjectMail;
			  $mail->AltBody = 'To view the message, please use an HTML compatible email viewer!'; // optional - MsgHTML will create an alternate automaticall//y
			  $mail->MsgHTML('You are registered to the gambay system with following credentials<br>
			  Email=>'.$email.
			  '<br>Username=>'.$username.
			  '<br>Password=>'.$password) ;
			  if(!$mail->Send()){
				//echo json_encode(array('success'=>'0','msg'=>'Error while sending Mail'));
			  }else{
				// echo json_encode(array('success'=>'1','msg'=>'Signup Complete Verify Email'));
			  }
			} catch (phpmailerException $e) {
			  //echo $e->errorMessage(); //Pretty error messages from PHPMailer
			} catch (Exception $e) {
			 // echo $e->getMessage(); //Boring error messages from anything else!
			}
		}	
	
		header("Location: $base$add$redirect?success=$success&msg=$msg");
		break;
		
	case "change-password":
	
		$success=$msg=null;
		$redirect=$_REQUEST['redirect'];
		$oldpass=$_REQUEST['oldpass'];
		$newpass=$_REQUEST['newpass'];
		
		$sth=$conn->prepare("select * from admin where password=:password");
		$sth->bindValue("password",md5($oldpass));
		
		try{$sth->execute();}
		catch(Exception $e){
		//echo $e->getMessage();
		}
		$result=$sth->fetchAll(PDO::FETCH_ASSOC);
		
		if(count($result) && $newpass && ($newpass==$_REQUEST['confirm'])){
			$newpass=md5($newpass);
			$sth=$conn->prepare("update admin set password=:password where name=:username");
			$sth->bindValue("username",'admin');
			$sth->bindValue("password",$newpass);
			$count=0;
			try{$count=$sth->execute();}catch(Exception $e){
			echo $e->getMessage();
			}
			if($count){
				$success=1;
				$msg="Password Updated!";
			}
			else{
				$success=0;
				$msg="Invalid Request! Try Again Later!";
				$redirect="changePassword.php";
			}
		}
		else{
			$success=0;
			
			/*if($newpass) $msg="All Fields are required!"; else */
			$msg="Passwords didn't match!";
			$redirect="changePassword.php";
		}
		
		
		header("Location: $redirect?success=$success&msg=$msg");
		break;
	
	
		case "manager-change-password":
	
		$success=$msg=null;
		$base="http://www.code-brew.com/projects/gambay/";
		$add="venue/";
		$username=$_REQUEST['username'];
		$redirect=$_REQUEST['redirect'];
		$oldpass=$_REQUEST['oldpass'];
		$newpass=$_REQUEST['newpass'];
		
		$sth=$conn->prepare("select * from manager where username=:username and password=:password");
		$sth->bindValue("password",md5($oldpass));
		$sth->bindValue("username",$username);
		try{$sth->execute();}
		catch(Exception $e){
		//echo $e->getMessage();
		}
		$result=$sth->fetchAll(PDO::FETCH_ASSOC);
		
		if(count($result) && $newpass && ($newpass==$_REQUEST['confirm'])){
			$newpass=md5($newpass);
			$sth=$conn->prepare("update manager set password=:password where username=:username");
			$sth->bindValue("username",$username);
			$sth->bindValue("password",$newpass);
			$count=0;
			try{$count=$sth->execute();}catch(Exception $e){
			echo $e->getMessage();
			}
			if($count){
				$success=1;
				$msg="Password Updated!";
			}
			else{
				$success=0;
				$msg="Invalid Request! Try Again Later!";
				$redirect="changePassword.php";
			}
		}
		else{
			$success=0;
			
			/*if($newpass) $msg="All Fields are required!"; else*/
			 $msg="Passwords didn't match!";
			$redirect="changePassword.php";
		}
		
		
		header("Location: $base$add$redirect?success=$success&msg=$msg");
		break;
	
	
}	
?>